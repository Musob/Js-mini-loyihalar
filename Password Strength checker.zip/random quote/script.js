window.addEventListener('DOMContentLoaded', () => {
	const quoteBox = document.getElementById('quote-box');	
	const btn = document.getElementById('btn');

	const quotes = [
				"Yurtni ilmli intellektual yoshlar yuksaltiradi.",
				"Life is 10% what happens to us and 90% how we react to it.",
				"Inson qadri doim ilm orqali bo'lgan.",
				"Your time is limited, so don’t waste it living someone else’s life.",
				"Hoh tan ol ,hoh tan olma ilmga chanqoq inson doim g'olib hisoblanadi."
		];
btn.addEventListener('click', () => {
	const randomIndex = Math.floor(Math.random()* quotes.length);
	quoteBox.textContent = quotes[randomIndex];
});
});
