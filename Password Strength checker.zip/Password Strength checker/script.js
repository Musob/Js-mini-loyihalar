const passwordInput = document.getElementById("password");
const strengthText = document.getElementById("strength-text");

// Show/Hide button yaratish
const toggleBtn = document.createElement("button");
toggleBtn.type = "button";
toggleBtn.textContent = "Show";
toggleBtn.id = "toggle-pw";

// inputning yoniga qo'shish
passwordInput.parentNode.insertBefore(toggleBtn, passwordInput.nextSibling);

// Tugma bosilganda password ko'rsatish / yashirish
toggleBtn.addEventListener("click", () => {
    if (passwordInput.type === "password") {
        passwordInput.type = "text";
        toggleBtn.textContent = "Hide";
    } else {
        passwordInput.type = "password";
        toggleBtn.textContent = "Show";
    }
});

// skeleton function (score qo‘shish o'zing qilasan)
function checkStrength(password) {
    let score = 0;

    if (password.length >= 8) score++;
    if (/[A-Z]/.test(password)) score++;
    if (/[a-z]/.test(password)) score++;
    if (/[0-9]/.test(password)) score++;
    if (/[^A-Za-z0-9]/.test(password)) score++;

    return score;
}

passwordInput.addEventListener("input", () => {
    const score = checkStrength(passwordInput.value);

    if (score === 0) strengthText.textContent = "Strength: Too weak";
    else if (score === 1) strengthText.textContent = "Strength: Very weak";
    else if (score === 2) strengthText.textContent = "Strength: Weak";
    else if (score === 3) strengthText.textContent = "Strength: Medium";
    else if (score === 4) strengthText.textContent = "Strength: Strong";
    else if (score === 5) strengthText.textContent = "Strength: Very Strong";
});
