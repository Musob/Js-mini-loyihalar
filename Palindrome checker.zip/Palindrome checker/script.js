window.addEventListener('DOMContentLoaded', (event) => {
	const input = document.querySelector(	'#text-input');
	const button = document.querySelector('#check-btn');
	const result = document.querySelector('#result');

	function isPalindrome(text) {
    // kichik harfga o'tkazamiz
    let cleaned = text.toLowerCase();
    // faqat harflar va raqamlarni qoldiramiz
    cleaned = cleaned.replace(/[^a-z0-9]/g, '');
    // teskarisini tekshiramiz
    const reversed = cleaned.split('').reverse().join('');
    return cleaned === reversed;
}



button.addEventListener('click', () => {
	const text = input.value;
	if(!text) {
		result.textContent = 'Please enter a text.';
		return;
	}
	if (isPalindrome (text)) {
		result.textContent = `"${text}" is a palindrome!`;
	} else {
		result.textContent = `"${text}" is not a palindrome.`;
	}
});
});