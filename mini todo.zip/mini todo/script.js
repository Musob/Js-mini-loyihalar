window.addEventListener('DOMContentLoaded', () => {
	const taskInput = document.getElementById('task-input');
	const addBtn = document.getElementById('add-btn');
	const taskList = document.getElementById('task-list');

	addBtn.addEventListener('click', () => {
		const taskText = taskInput.value;

		if(taskText === '') {
			alert('Please enter a task.');
			return;
		}

		const li = document.createElement('li');
		li.textContent = taskText;
		
		taskList.appendChild(li);
		input.value = '';
	});
});