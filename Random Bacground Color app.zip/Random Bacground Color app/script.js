window.addEventListener('DOMContentLoaded', (event) => {
	const btn = document.getElementById('btn');
	const colorCode = document.getElementById('color-code');

	document.body.style.transition = 'background-color 400ms ease';

	function getRandomHex() {
				return '#' + Math.floor(Math.random() * 0xFFFFFF).toString(16).padStart(6, '0');
			
	}
	
	function getContrastColor(hex) {
		const clean = hex.replace('#', '');
		const r = parseInt(clean.substr(0, 2), 16);
		const g = parseInt(clean.substr(2, 2), 16);
		const b = parseInt(clean.substr(4, 2), 16);
		const brightness = (r * 299 + g * 587 + b * 114) / 1000;
		return brightness > 125 ? '#000000' : '#FFFFFF';
	}

	btn.addEventListener('click', () => {
	const color = getRandomHex();
	document.body.style.backgroundColor = color;
	colorCode.textContent = color;

	const contrast = getContrastColor(color);
	colorCode.style.color = contrast;
	btn.style.color = contrast;
	});
});